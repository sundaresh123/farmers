 <!-- Stylesheets -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/revolution-slider.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!--Favicon-->
    <link rel="shortcut icon" href="images/favicon.jpg" type="image/x-icon">
    <link rel="icon" href="images/favicon.jpg" type="image/x-icon">
    <!-- Responsive -->
    
    <link href="css/responsive.css" rel="stylesheet"> 