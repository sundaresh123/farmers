<?php 
$conn=mysqli_connect("localhost","root","","ngo") or
 die('could not connect'.mysql_error());
 

?>