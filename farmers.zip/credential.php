<?php
	/*Update credentials*/
	define('EMAIL', 'karthi43000@gmail.com');
	define('PASS', 'aaaaaasssss');
 ?>